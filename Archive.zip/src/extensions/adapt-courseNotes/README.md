# adapt-courseNotes

**courseNotes** is an *extension* to allows you to save text notes using local storage

You can see it [here](https://adaptlearning-no-core.web.app/#/id/eo-30)
 

----------------------------
**Version number:**  1.0.0  
**Framework versions:**  5.17.7+     
**Author / maintainer:**  [Nacho Cinalli](https://github.com/nachocinalli/)    
**Accessibility support:**    
**RTL support:**  
**Cross-platform coverage:** 