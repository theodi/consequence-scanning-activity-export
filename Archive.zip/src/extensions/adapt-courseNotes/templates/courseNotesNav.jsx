import React from 'react';

export default function CourseNotesNav(props) {
  return (
    <span className='icon'></span>
  );
}
