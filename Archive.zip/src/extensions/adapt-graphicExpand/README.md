# adapt-graphicExpand
## An extension to allow the learner to expand a graphic to full screen