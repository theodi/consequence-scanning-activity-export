# adapt-dnd-multiple
**adapt-dnd-multiple** is a presentation component. You can see it [here](https://adaptlearning-no-core.web.app/#/id/qo-35).

## Settings Overview
The attributes are used in components.json and are properly formatted as JSON in  [*example.json*](https://github.com/nachocinalli/adapt-dnd-multiple/blob/master/example.json).

----------------------------


**Author / maintainer:** [Ignacio Cinalli] (https://github.com/nachocinalli)  