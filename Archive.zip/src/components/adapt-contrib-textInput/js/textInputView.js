import QuestionView from "core/js/views/questionView";
class TextInputView extends QuestionView {
  events() {
    return {
      "focus .js-textinput-textbox": "clearValidationError",
      "change .js-textinput-textbox": "onInputChanged",
      "keyup .js-textinput-textbox": "onInputChanged",
      "click .js-textinput-add": "onAddButtonClick",
    };
  }

  onAddButtonClick(e) {
    e.preventDefault();

    // Create a new object with desired properties
    const newItem = {
      prefix: "", // Add desired value or leave empty
      _index: this.model.get("_items").length,
      input: "", // Add desired value or leave empty
      placeholder: "Enter text", // Add desired value or leave empty
      userAnswer: "",
      suffix: "", // Add desired value or leave empty
    };

    // Add the new object to the _items array
    this.model.get("_items").push(newItem);

    // Rerender the view to reflect the change
    this.render();
  }

  setupQuestion() {
    this.model.setupRandomisation();
  }

  disableQuestion() {
    this.setAllItemsEnabled(false);
  }

  enableQuestion() {
    this.setAllItemsEnabled(true);
  }

  setAllItemsEnabled(isEnabled) {
    this.model.get("_items").forEach((item, index) => {
      const $itemInput = this.$(".js-textinput-textbox").eq(index);

      $itemInput.prop("disabled", !isEnabled);
    });
  }

  onQuestionRendered() {
    this.setReadyStatus();
  }

  clearValidationError() {
    this.$(".js-textinput-textbox").removeClass("has-error");
  }

  // Blank method for question to fill out when the question cannot be submitted
  onCannotSubmit() {
    this.showValidationError();
  }

  showValidationError() {
    this.$(".js-textinput-textbox").addClass("has-error");
  }

  // This is important and should give the user feedback on how they answered the question
  // Normally done through ticks and crosses by adding classes
  showMarking() {
    if (!this.model.get("_canShowMarking")) return;

    this.model.get("_items").forEach((item, i) => {
      const $item = this.$(".js-textinput-item").eq(i);
      $item
        .removeClass("is-correct is-incorrect")
        .addClass(item._isCorrect ? "is-correct" : "is-incorrect");
    });
  }

  // Used by the question view to reset the look and feel of the component.
  resetQuestion() {
    this.$(".js-textinput-textbox")
      .prop("disabled", !this.model.get("_isEnabled"))
      .val("");

    this.model.set({
      _isAtLeastOneCorrectSelection: false,
      _isCorrect: undefined,
    });
  }

  showCorrectAnswer() {
    const correctAnswers = this.model.get("_answers");
  
    if (!correctAnswers || correctAnswers.length === 0) {
      console.error("No correct answers found in the model.");
      return;
    }
  
    const items = this.model.get("_items");
    if (!items || items.length === 0) {
      console.error("No items found in the model.");
      return;
    }
  
    items.forEach((item, index) => {
      if (index >= correctAnswers.length) {
        console.error("Index out of bounds for correctAnswers.");
        return;
      }
  
      const correctAnswer = correctAnswers[index][0];
      if (typeof correctAnswer === "undefined") {
        console.error("Correct answer is undefined for index:", index);
        return;
      }
  
      this.$(".js-textinput-textbox").eq(index).val(correctAnswer);
    });
  }

  hideCorrectAnswer() {
    this.model.get("_items").forEach((item, index) => {
      this.$(".js-textinput-textbox").eq(index).val(item.userAnswer);
    });
  }

  onInputChanged(e) {
    const $input = $(e.target);
    this.model.setItemUserAnswer(
      $input.parents(".js-textinput-item").index(),
      $input.val()
    );
  }
}

TextInputView.template = "textinput.jsx";

export default TextInputView;
